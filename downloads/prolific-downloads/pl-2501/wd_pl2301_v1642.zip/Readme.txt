
PL-2301 USB-to-USB Data Bridge Cable
=========================
Release Information

App (PC-Linq) Version: V1.6.4.2
Driver Version for Win98 & ME: V1.6.0.0
Driver Version for Win2K: V1.6.0.0
Released date: 03/03/2003

-------------------------------		
Files Included in This Release:
	Coinst.dll
	PL-2301.cat  
        	Readme.txt
        	Setup.exe
        	Usbbc.inf
	Usbbc.sys
	Usbbc.ini

-------------------------------		
Changes in This Release:
	1. Fix PC-Linq no response on standby (suspend) under Windows XP and 2000.



=========================
Prolific Technology Inc.
http://tech.prolific.com.tw



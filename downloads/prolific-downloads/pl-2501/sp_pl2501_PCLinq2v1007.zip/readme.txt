
Prolific Technology Inc.
PL-2501 Hi-Speed USB Bridge Cable Setup Program
=========================================

Setup Program Release Date: 07/08/2003
Setup Program Version: 1.0.0.7

AP Version: 
	pclinq2a.exe  --  1.0.0.7
	pclinq2u.exe  --  1.0.0.7
	uninst.exe  --      1.0.0.1

Driver Versions:
	usbbc2.sys -- 2.0.0.20
	linkliba.dll -- 1.0.0.7
	linklibu.dll -- 1.0.0.7

=========================================

Revision History: 

=> Release v1.0.0.7

linklibx.dll : 1.0.0.7
pclinq2x.exe : 1.0.0.7

  1. Fix bug that will change filename file attributes to read only after DBClick file and refresh.

---------------------------------------------------

=> Release v1.0.0.6

linklibx.dll : 1.0.0.6
pclinq2x.exe : 1.0.0.6
English.ini

  1. Modify DLL resource version.
  2. Fix string error in PCLinq2 AP.

---------------------------------------------------

=> Release v1.0.0.5

linklibx.dll : 1.0.0.5
pclinq2x.exe : 1.0.0.5

  1. Fix Win98 customer report: sometimes local copy to remote and unplug local cable, local AP will hang.
  2. Fix WinXP customer report: USB1.1 + USB mouse + PL-2501 : First plug cable then run AP , sometimes cannot copy file folders from local to remote.
  3. Modify USBCMD_WriteFile error code.
  4. Reversion pclinq2x.exe

---------------------------------------------------

=> Release v1.0.0.4

linklibx.dll : 1.0.0.4
pclinq2x.exe : 1.0.0.4

  1. Fix AP disconnect error at transfer, with disable its action.
  2. Unplug and application crash under transferring, it can't rebuild at this version.

---------------------------------------------------

=> Release v1.0.0.3

linklibx.dll : 1.0.0.3
pclinq2x.exe : 1.0.0.3
usbbc2.sys : 2.0.0.20
usbbc2.inf : 2.0.0.20
English.ini 

  1. Fix for hardware turnround error with AP close connect.
  2. Remove chinese resource descriptor.
  3. Fix for copy directory error with unplug cable.
  4. Fix for hot key unused error when options->ok
  5. Fix toolbar hit box information.
  6. Fix for L->R copy and cancel error.
  7. Remove restart/shutdonw message box error.
  8. Add Rename Menu in Language (English) INI.
  9. Fix standy alert.
  10. Add message box when standy under busy
  11. Fix suspend/wakeup and close with memory leak.
  12. Fix for driver list error
  13. Fix for transfer error when shutdown/restart.
  14. Add setting for show safty remove device.
  15. Fix of changing device mode
  16. Fix of multi opening application
  17. Fix of changing device mode
  18. Fix of multi opening application of different code page
  19. Fix for crash at HCT 11.1a
  20. Add support for full customer.
  21. Fix Configure Label Length for long string.
  22. Add Set dll configure of memory block size.
  23. Fix change language multi-times will cause some menu items disappear.
  24. Fix type characters in options->Language, will cause Application crash.

---------------------------------------------------

=> Release v1.0.0.2

  1. Add retry error to 10 times
  2. Add check background process busy for suspend.
  3. Prevent suspend during file transfer.
  4. Add formatted file size display in language ini. 

---------------------------------------------------

=> Release v1.0.0.1 

  1. Fix blue screen issue at 98/ME when plug-unplug.
  2. Fix WHQL HCT bugs.
  3. Modify parameters call for uninst error.
  4. Extend to 20 cables plugin at the same time.
  5. Support more than one ID for remove.
  6. Fix date/rime display error.
  7. Add support for PL2301 old cable.
  8. Change interrupt interval at pl2301.

---------------------------------------------------

=> Release v1.0.0.0
1. Modify release v0.0.0.57b2 driver set to release v1.0.0.0.

---------------------------------------------------

=> Release v0.0.0.57 b2

linklibx.dll: 0.0.0.61
  1.   Can't connect under ME/98 when reopen application.
  2.   More stable on unplug.
  3.   More stable on reconnect.
  4.   Fix can't connect at 2K.
  5.   Fix can't reconnect ver 1B chip after unplug/plug in WinXP.
  6.   Fix Win98 will crash in ver 1B chip.
  7.   Fix can't connect in ver 3A chip.
  8.   Fix move file failure from local to remote.
  9.   Add support cancel in multi-cable copy/move.
  10. Fix can't display progress when copy small files.
  11. Add OS version display for Mac/Linux/Unix.

pclinq2x.exe : 0.0.0.57
  1.   Remove dispaly USB type for ver 5A chip.
  2.   Fix Win98 crash when plug & play with AP open.
  3.   Fix can't finish transfer over 600mb files under win98.
  4.   Remove speed button for remotewakeup.
  5.   Add prevent open more than one application.
  6.   Fix cannot move file folder with files. 
  7.   Fix cancel crash for copy/move files.

pclinq.ini
  1.   Add do not display device running USB mode for ver 3A or previous chip.
  2.   Add set for changedevicenode/remotewakeup menu enable/disable in ini.

---------------------------------------------------
=> Release v0.0.0.51b3:

pclinq2x.exe : 0.0.0.51
  1. Fix unplug when copy files error ( from local copy to remote ).
  2. Add error message for dll return. 

linklibx.dll : 0.0.0.52
  1. Fix for replugin and reconnect intermittent failure.
  2. Improve reliability in reconnect.
  3. Page fault when unplug.


=========================================
Prolific Technology Inc.
http://tech.prolific.com.tw


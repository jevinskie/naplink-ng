Release Information

App (PC-Linq) Version: V1.63
Driver Version for Win98 & Me: V1.6.0.0
Driver Version for Win2K: V1.6.0.0
Released date: 09/12/2001

Files Included in This Release:
	Coinst.dll
        Pl-2301.cat  
        Readme.txt
        Setup.exe
        Usbbc.inf
	Usbbc.sys
	Usbbc.ini
		
Changes in This Release:
	1. To fix the suspend issue on Windows 2000.
        2. This version can support Win98/ME/2000/XP and passed WHQL test procedure for Win XP 
           and got the Win XP catalog file. 

	


Release Information

Driver Version : V1.6.0.0
Released date: 08/02/2001

USB-USB Network Bridge1.6.0.0.exe Includes Files in This Release:
	USB2000.INF
	PRO2000.INF
	NIC2000.INF
	USB2000.SYS
	PRO2000.SYS
	NIC2000.SYS
	README.TXT
	
Changes in This Release:
        1. To fix the issue that can't use ReadWriteSpinLock in Win98.

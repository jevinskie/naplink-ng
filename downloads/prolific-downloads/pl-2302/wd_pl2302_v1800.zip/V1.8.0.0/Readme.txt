Release Information

Driver Version : V1.8.0.0
Released date: 11/05/2001

USB-USB Network Bridge1.8.0.0.exe Includes Files in This Release:
	USB2000.INF
	PRO2000.INF
	NIC2000.INF
	USB2000.SYS
	PRO2000.SYS
	NIC2000.SYS
	README.TXT
	
Changes in This Release:
        1. To fix the Hibernation issue that can support for WinXP.

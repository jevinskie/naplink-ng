Release Note
Prolific PCLinq3 for PL-25A1 Easy Transfer Cable
For Windows Vista/XP/2000/ME/98SE
v3.1.0.3, Generic Edition
===================================================

NOTE: Prolific only supplies the PL-25A1 controller chip, PCLinq3 drivers, and the PCLinq3 software to customers for designing and manufacturing their cable products. Prolific "DOES NOT" manufacture any consumer cable end-products and is not responsible for supporting end-users. PL-25A1 device drivers for Windows Vista and Windows XP (SP2) are provided by Microsoft using Windows Easy Transfer (WET) program. PCLinq3 is only for PL-25A1 chip and is not compatible with PL-2501 controller chip.


Introduction
-------------
PCLinq3 is a user-friendly file manager program that allows you to see and control file directories on both PCs at the same time. You can easily drag-and-drop or cut-and-paste files and folders between PCs as well as creating new folders and changing file attributes. PCLinq3 is designed to be used in addition to Windows Easy Transfer for Windows Vista and XP. PCLinq3 can also work separately under Windows 2000, ME, and 98SE.


Revision Change:
-------------------------
PCLinq3 v3.1.0.2 add support to Windows XP x64.
PCLinq3 v3.1.0.3 fixed sometimes will appear "Update Windows..." message box during file transfer.


System Requirements 
--------------------
1. Two computers running either Microsoft Windows Vista, Windows XP with Service Pack 2 (SP2), Windows 2000, Windows ME, or Windows 98SE. 
2. Pre-installed Windows Easy Transfer (WET) program for Windows XP and Vista
3. DVD or CDROM drive for installing program CD
4. At least 200MB of hard disk space must be available
5. One standard USB 1.1 or USB 2.0 (recommended) port for each PC


Installing the Windows Easy Transfer (WET) Program
---------------------------------------------------
Before you can use the PCLinq3 program under Windows XP or Windows Vista, you first need to have the Microsoft Windows Easy Transfer (WET) program pre-installed for supporting Microsoft Windows USB class driver (winusb.sys). Windows Easy Transfer (WET) program is already built inside Windows Vista so you only need to install the program for Windows XP with Service Pack 2 (SP2). 

1. Insert the Windows Easy Transfer (WET) Installer CD into your Windows XP PC drive to launch the installation wizard and help you install the program. Do the same installation process for the other PC that you will link together.

2. After installation is complete, you can now plug-in the USB Easy Transfer Cable to the USB port. The Easy Transfer Cable auto play window will pop out for you to run instantly. You can click OK to launch Windows Easy Transfer program.
 
3. You can also go to the Control Panel�VSystem�VDevice Manager to view the device properties. You should see "USB Easy Transfer Cable" device under the Transfer Cable Devices. 


Installing the PCLinq3 Setup Program
-------------------------------------
The following steps will guide you how to install the PCLinq3 software for Windows Vista, Windows XP, Windows 2000, Windows ME, and Windows 98SE. PCLinq3 is a user-friendly file manager program that allows you to see and control file directories on both PCs at the same time.

1. If you are running Windows Vista or Windows XP, you are required to install the Windows Easy Transfer program first. The Easy Transfer Cable uses the same device driver (winusb.sys) provided in Windows Easy Transfer program for Windows Vista and Windows XP.  

2. Load the PCLinq3 Installer CD and run the SETUP.EXE executable program file. The Setup program will then start to prepare the InstallShield Wizard that will guide you through the rest of the setup process.

3. The InstallShield Wizard welcome dialog box will then appear to display some information regarding the Setup program. Follow the instructions and click Next to continue and follow the succeeding instructions to complete the installation. 

4. After installation is complete, click Start and Program Files and check if the Prolific PCLinq3 program folder was created. For Windows Vista, XP and 2000, there are two programs provided: ANSI mode and Unicode mode. For Windows 98 and ME, only the ANSI mode is provided. 

 
Running the PCLinq3 Program
----------------------------
The PCLinq3 program allows you to easily link two computers by plugging each end of the Easy Transfer cable into the USB port of both computers. Before you can start using the PCLinq3 program, you need first to run Setup program on both computers and install the bridge cable as mentioned in the previous section. 

PCLinq3 is an application program used to control the file sharing and data transfer of the linked computers (also known as the local PC and the remote PC). After you have successfully completed the Setup programs and plug-in the Easy Transfer cable, you simply click and run the PCLinq3 program found in the PCLinq3 program folder. 

With PCLinq3, you can control both the local and remote PCs and do the following:
(1) Display files/folders 
(2) Open files/folders
(3) Create files/folders
(4) Delete files/folders
(5) Copy files/folders
(6) Move files/folders 
(7) Change file/folder names
 
To start using PCLinq3:
1. Plug the one end of the Easy Transfer cable into the USB port of one computer and the other end into the USB port of the other computer. Note that after installing the program for the first-time under Windows XP, you are required to first plug-in the cable before you can open the PCLinq3 program.

2. Wait for Windows to detect the cable on each computer and check if it is properly installed.

3. Click Start-Programs-PCLinq3 to access the PCLinq3 programs. It is important that you use the same program mode for each computer. If you are using ANSI mode, then both computers should be running the ANSI mode program. Check the Status LED on the bottom right of the program dialog box if it is ready or not. A green LED signifies a ready status while a red LED means not ready or not found. Make sure that the program shows two green LEDs to indicate a linked connection.

Note: The Unicode program is only supported in Windows Vista, Windows XP, and Windows 2000. The ANSI program is available for all Windows OS versions. Use the PCLinq3 Unicode version if both PCs have Windows 2000 or above versions.

4. Once a connection has been established, you simply drag-and-drop the files or folders you want to transfer to the other computer. You can change disk drives or directories by clicking on the pull-down directory menu. You can also use the Menu Controls (File, Edit, Command, View, Help) for other functions of the program. There is also the Icon Controls for common used commands. 

 
Uninstalling the PCLinq3 Bridge Cable
-------------------------------------
It is easy to uninstall the PCLinq3 program. 

1. Make sure to first unplug the Easy Transfer cable and close the PCLinq3 program. 

2. Go to Control Panel and double-click on Add or Remove Programs. Look for the PCLinq3 program and click Remove button.

3. The PCLinq3 InstallShield Wizard program will appear and let you choose if you want to Modify, Repair or Remove installations. Click the Remove button selection to remove all installations. Make sure that you have unplugged the Easy Transfer cable and click Next to continue.

4. The PCLinq3 InstallShield Wizard program will confirm with you if you really want to completely remove the application and features. Click Yes to uninstall. 

5. Wait for the InstallShield Wizard program to complete uninstallation. Click Finish when uninstall is complete. 


Disclaimer
----------
All the information in this document is subject to change without prior notice. The manufacturer does not make any representations or any warranties (implied or otherwise) regarding the accuracy and completeness of this document and shall in no event be liable for any loss of profit or any other commercial damage, including but not limited to special, incidental, consequential, or other damages.

No part of this document may be reproduced or transmitted in any form by any means without the express written permission of the manufacturer. 

All brand names and product names used in this document are trademarks or registered trademarks of their respective holders. 


===================================================
Prolific Technology Inc. 
http://www.prolific.com.tw


